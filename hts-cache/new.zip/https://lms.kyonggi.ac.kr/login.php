<!DOCTYPE html>
<html  dir="ltr" lang="en" xml:lang="en" class="html_login">
<head>
    <title>경기대학교 LMS</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, target-densitydpi=medium-dpi" />
    <meta name="keywords" content="moodle, coursemos, 코스모스">
    <link rel="shortcut icon" href="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme/1693408461/favicon" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, 경기대학교 LMS: Log in to the site" />
<link rel="stylesheet" type="text/css" href="https://lms.kyonggi.ac.kr/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.css" /><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="https://lms.kyonggi.ac.kr/theme/styles.php/coursemosv2/1693408461/all" />
<script type="text/javascript">
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"https:\/\/lms.kyonggi.ac.kr","sesskey":"48Ols5IkKh","loadingicon":"https:\/\/lms.kyonggi.ac.kr\/theme\/image.php\/coursemosv2\/core\/1693408461\/i\/loading_small","themerev":"1693408461","slasharguments":1,"theme":"coursemosv2","jsrev":"1693408461","admin":"admin","svgicons":true};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''}
if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else{me.path=component+'/'+component+'.'+me.type}};
YUI_config = {"debug":false,"base":"https:\/\/lms.kyonggi.ac.kr\/lib\/yuilib\/3.17.2\/","comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"https:\/\/lms.kyonggi.ac.kr\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?m\/1693408461\/","combine":true,"comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","ext":false,"root":"m\/1693408461\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-core-checknet":{"requires":["base-base","moodle-core-notification-alert","io-base"]},"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-dock":{"requires":["base","node","event-custom","event-mouseenter","event-resize","escape","moodle-core-dock-loader","moodle-core-event"]},"moodle-core-dock-loader":{"requires":["escape"]},"moodle-core-dragdrop":{"requires":["base","node","io","dom","dd","event-key","event-focus","moodle-core-notification"]},"moodle-core-event":{"requires":["event-custom"]},"moodle-core-formautosubmit":{"requires":["base","event-key"]},"moodle-core-formchangechecker":{"requires":["base","event-focus","moodle-core-event"]},"moodle-core-handlebars":{"condition":{"trigger":"handlebars","when":"after"}},"moodle-core-languninstallconfirm":{"requires":["base","node","moodle-core-notification-confirm","moodle-core-notification-alert"]},"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core-maintenancemodetimer":{"requires":["base","node"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","escape","event-key","dd-plugin","moodle-core-widget-focusafterclose","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-popuphelp":{"requires":["moodle-core-tooltip"]},"moodle-core-tooltip":{"requires":["base","node","io-base","moodle-core-notification-dialogue","json-parse","widget-position","widget-position-align","event-outside","cache-base"]},"moodle-core_availability-form":{"requires":["base","node","event","event-delegate","panel","moodle-core-notification-dialogue","json"]},"moodle-backup-backupselectall":{"requires":["node","event","node-event-simulate","anim"]},"moodle-backup-confirmcancel":{"requires":["node","node-event-simulate","moodle-core-notification-confirm"]},"moodle-calendar-info":{"requires":["base","node","event-mouseenter","event-key","overlay","moodle-calendar-info-skin"]},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-course-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-course-coursebase","moodle-course-util"]},"moodle-course-formatchooser":{"requires":["base","node","node-event-simulate"]},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-course-modchooser":{"requires":["moodle-core-chooserdialogue","moodle-course-coursebase"]},"moodle-course-toolboxes":{"requires":["node","base","event-key","node","io","moodle-course-coursebase","moodle-course-util"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-form-dateselector":{"requires":["base","node","overlay","calendar"]},"moodle-form-passwordunmask":{"requires":[]},"moodle-form-shortforms":{"requires":["node","base","selector-css3","moodle-core-event"]},"moodle-form-showadvanced":{"requires":["node","base","selector-css3"]},"moodle-core_message-messenger":{"requires":["escape","handlebars","io-base","moodle-core-notification-ajaxexception","moodle-core-notification-alert","moodle-core-notification-dialogue","moodle-core-notification-exception"]},"moodle-question-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-question-preview":{"requires":["base","dom","event-delegate","event-key","core_question_engine"]},"moodle-question-qbankmanager":{"requires":["node","selector-css3"]},"moodle-question-searchform":{"requires":["base","node"]},"moodle-availability_completion-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_date-form":{"requires":["base","node","event","io","moodle-core_availability-form"]},"moodle-availability_grade-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_group-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_grouping-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_profile-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-qtype_ddimageortext-dd":{"requires":["node","dd","dd-drop","dd-constrain"]},"moodle-qtype_ddimageortext-form":{"requires":["moodle-qtype_ddimageortext-dd","form_filepicker"]},"moodle-qtype_ddmarker-dd":{"requires":["node","event-resize","dd","dd-drop","dd-constrain","graphics"]},"moodle-qtype_ddmarker-form":{"requires":["moodle-qtype_ddmarker-dd","form_filepicker","graphics","escape"]},"moodle-qtype_ddwtos-dd":{"requires":["node","dd","dd-drop","dd-constrain"]},"moodle-qtype_stack-input":{"requires":["node","event-valuechange","moodle-core-event","io","json-parse"]},"moodle-mod_assign-history":{"requires":["node","transition"]},"moodle-mod_forum-subscriptiontoggle":{"requires":["base-base","io-base"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form"]},"moodle-mod_quiz-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-base","moodle-mod_quiz-util-page","moodle-mod_quiz-util-slot","moodle-course-util"]},"moodle-mod_quiz-modform":{"requires":["base","node","event"]},"moodle-mod_quiz-questionchooser":{"requires":["moodle-core-chooserdialogue","moodle-mod_quiz-util","querystring-parse"]},"moodle-mod_quiz-quizbase":{"requires":["base","node"]},"moodle-mod_quiz-quizquestionbank":{"requires":["base","event","node","io","io-form","yui-later","moodle-question-qbankmanager","moodle-core-notification-dialogue"]},"moodle-mod_quiz-randomquestion":{"requires":["base","event","node","io","moodle-core-notification-dialogue"]},"moodle-mod_quiz-repaginate":{"requires":["base","event","node","io","moodle-core-notification-dialogue"]},"moodle-mod_quiz-toolboxes":{"requires":["base","node","event","event-key","io","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-slot","moodle-core-notification-ajaxexception"]},"moodle-mod_quiz-util":{"requires":["node","moodle-core-actionmenu"],"use":["moodle-mod_quiz-util-base"],"submodules":{"moodle-mod_quiz-util-base":{},"moodle-mod_quiz-util-slot":{"requires":["node","moodle-mod_quiz-util-base"]},"moodle-mod_quiz-util-page":{"requires":["node","moodle-mod_quiz-util-base"]}}},"moodle-message_airnotifier-toolboxes":{"requires":["base","node","io"]},"moodle-block_navigation-navigation":{"requires":["base","io-base","node","event-synthetic","event-delegate","json-parse"]},"moodle-filter_glossary-autolinker":{"requires":["base","node","io-base","json-parse","event-delegate","overlay","moodle-core-event","moodle-core-notification-alert","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-filter_mathjaxloader-loader":{"requires":["moodle-core-event"]},"moodle-editor_atto-editor":{"requires":["node","transition","io","overlay","escape","event","event-simulate","event-custom","node-event-html5","node-event-simulate","yui-throttle","moodle-core-notification-dialogue","moodle-core-notification-confirm","moodle-editor_atto-rangy","handlebars","timers","querystring-stringify"]},"moodle-editor_atto-plugin":{"requires":["node","base","escape","event","event-outside","handlebars","event-custom","timers","moodle-editor_atto-menu"]},"moodle-editor_atto-menu":{"requires":["moodle-core-notification-dialogue","node","event","event-custom"]},"moodle-editor_atto-rangy":{"requires":[]},"moodle-report_eventlist-eventfilter":{"requires":["base","event","node","node-event-delegate","datatable","autocomplete","autocomplete-filters"]},"moodle-report_loglive-fetchlogs":{"requires":["base","event","node","io","node-event-delegate"]},"moodle-gradereport_grader-gradereporttable":{"requires":["base","node","event","handlebars","overlay","event-hover"]},"moodle-gradereport_history-userselector":{"requires":["escape","event-delegate","event-key","handlebars","io-base","json-parse","moodle-core-notification-dialogue"]},"moodle-tool_capability-search":{"requires":["base","node"]},"moodle-tool_lp-dragdrop-reorder":{"requires":["moodle-core-dragdrop"]},"moodle-tool_monitor-dropdown":{"requires":["base","event","node"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","event-resize","transition","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-atto_accessibilitychecker-button":{"requires":["color-base","moodle-editor_atto-plugin"]},"moodle-atto_accessibilityhelper-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_align-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_bold-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_charmap-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_clear-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_collapse-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_coursemosvimeo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emoticon-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_equation-button":{"requires":["moodle-editor_atto-plugin","moodle-core-event","io","event-valuechange","tabview","array-extras"]},"moodle-atto_html-button":{"requires":["moodle-editor_atto-plugin","event-valuechange"]},"moodle-atto_image-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_indent-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_italic-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_link-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-usedfiles":{"requires":["node","escape"]},"moodle-atto_media-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_noautolink-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_orderedlist-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_pasteimage-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_pbltemplate-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_poodll-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_rtl-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_strike-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_subscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_superscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_table-button":{"requires":["moodle-editor_atto-plugin","moodle-editor_atto-menu","event","event-valuechange"]},"moodle-atto_title-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_underline-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_undo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_unorderedlist-button":{"requires":["moodle-editor_atto-plugin"]}}},"gallery":{"name":"gallery","base":"https:\/\/lms.kyonggi.ac.kr\/lib\/yuilib\/gallery\/","combine":true,"comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","ext":false,"root":"gallery\/1693408461\/","patterns":{"gallery-":{"group":"gallery"}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"https:\/\/lms.kyonggi.ac.kr\/lib\/javascript.php\/1693408461\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker"]},"core_comment":{"name":"core_comment","fullpath":"https:\/\/lms.kyonggi.ac.kr\/lib\/javascript.php\/1693408461\/comment\/comment.js","requires":["base","io-base","node","json","yui2-animation","overlay","escape"]}}};
M.yui.loader = {modules: {}};

//]]>
</script>

<meta property="og:type" content="website" />
<meta property="og:title" content="경기대학교 학습관리시스템" />
<meta property="og:description" content="KYONGGI University, Center for Teaching and Learning" />
<meta property="og:image" content="null" />
<meta property="og:url" content="http://lms.kyonggi.ac.kr" />

<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.5.1/css/iziModal.min.css">


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-5JX2E4WFHT"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-5JX2E4WFHT');
</script>    <link href="/theme/coursemosv2/style/main_login.css" rel="stylesheet" type="text/css" />
</head>

<body id="page-login-index" class="loginpage_2 ">
<div class="skiplinks">
    <a href="#maincontent" class="skip">Skip to main content</a>
</div><script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.js&amp;rollup/1693408461/mcore-min.js"></script><script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/core/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/core/ui-1.12.1/jquery-ui.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/bootstrap.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.cookie.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.validate.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.validate.methods.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.tableHeadFixer.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery-sortable.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/moment.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/fullcalendar.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/gcal.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.filedownload.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/timer.jquery.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.validate.en.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.headroom.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/javascript-static.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/javascript.php/coursemosv2/1693408461/head"></script>
<script type="text/javascript">
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>

<script type="text/javascript">
	$(function() {
		M.theme_coursemosv2.login();
	});
</script>
<div id="page">
	<div id="page-content" class="clearfix">
		<div id="region-main">
			<div role="main"><span id="maincontent"></span><script type="text/javascript" src="/theme/coursemosv2/jquery/jquery.dotdotdot.min.js"></script>
<script type="text/javascript">

	$(function() {
				$("#username").focus();
		
		$(".loginform").validate();

		$(".notice_more_view").click(function() {
			$("#board_more").attr("href", "https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=1");
		});

		$(".qna_more_view").click(function() {
			$("#board_more").attr("href", "https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=2");
		});
		
	});
	
</script>

<!-- main_login_wrapper -->
<div class="main_login_wrapper"> 
  
  	<!-- main_login_bg-->
  	<div class="main_login_bg"> 
    
    	<!-- main_visual_txt -->
    	<div class="main_visual_txt">
      		<p>ALL BARUN 참인재<br />
      		<span>KYONGGI UNIVERSITY</span></p>
    	</div>
    	<!-- //main_visual_txt --> 
    
    	<!-- main_login_bar -->
    	<div class="main_login_bar">
      	<h1></h1>
      
      	<!-- main_login_box -->
      	<div class="main_login_box login_form">
        	<h3>LOGIN</h3>
        	<form action="https://lms.kyonggi.ac.kr/login/index.php" method="post" class="loginform">
        		        	<div class="form-group">
	          		<input type="text" id="username" name="username" class="main_login_input required" placeholder="Username" value="" />
	        	</div>
	        	<div class="form-group">
	          		<input type="password" id="password" name="password" class="main_login_input required" placeholder="Password" />
	        	</div>
	        	<div class="form-group">
	          		<button type="submit" class="main_login_btn">Login</button>
	        	</div>
	        	<div class="login-remember">
	          		<label class="main_login_txt">
	            		<input type="checkbox" id="remember" name="rememberusername"  />
	            		Remember username 
	            	</label>
	        	</div>
	        		        	<div class="main_login_find_idpw_sso"> <a href="http://kutis.kyonggi.ac.kr/webkutis/index.jsp" target="_blank">Find ID / PW</a> </div>
	        	<div class="main_login_find_idpw">
	        	</div>
	        	<div class="main_login_find_idpw">	          	
					<a href="https://lms.kyonggi.ac.kr/login/register_agree.php">Join the public</a>
				</div>
		        <div class="main_login_find_idpw public">	          	
					<a href="https://lms.kyonggi.ac.kr/login/forgot_password.php">Find ID/Password(public)</a>
				</div>
	        	    		</form>
  		</div>
  
  		<!-- //main_login_box --> 
  
  		<!-- main_login_bottom -->
  		<div class="main_login_bottom">
    		<div class="main_login_lang dropdown langdropdown"><a href="#" id="user-language" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nobtn dropdown-toggle">English ‎<span class="caret"></span></a><ul class="dropdown-menu" role="menu" aria-labelledby="user-language"><li><a href="https://lms.kyonggi.ac.kr/login.php?lang=en" title="English ‎(en)‎">English ‎(en)‎</a><span class="natinal_flag"><img src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme_coursemosv2/1693408461/flag/en" alt="en" /></span></li><li><a href="https://lms.kyonggi.ac.kr/login.php?lang=ko" title="한국어 ‎(ko)‎">한국어 ‎(ko)‎</a><span class="natinal_flag"><img src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme_coursemosv2/1693408461/flag/ko" alt="ko" /></span></li><li><a href="https://lms.kyonggi.ac.kr/login.php?lang=zh_cn" title="简体中文 ‎(zh_cn)‎">简体中文 ‎(zh_cn)‎</a><span class="natinal_flag"><img src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme_coursemosv2/1693408461/flag/zh_cn" alt="zh_cn" /></span></li></ul></div>    
    		<!-- SNS -->
		    <div class="main_login_sns"> 
		    	<a href="https://www.facebook.com/kyonggiuniv1/" target="_blank" class="main_login_fb">facebook</a>
		    	<!--<a href="#" target="_blank" class="main_login_twit">twitter</a>-->
		    </div>
		    <div class="main_login_line">
		      	<div class="line"></div>
		    </div>
		    <div class="main_login_privacy"> 
		    	<a href="http://www.kyonggi.ac.kr/webService.kgu?menuCode=K00M05020000" target="_blank">Privacy Policy</a>
		    </div>
    
		    <!-- main_login_copy -->
		    <div class="main_login_copy">
		        154-42, Kyounggi univ., Gwanggyosan-ro, Yeongtong-gu, Suwon-si, Gyeonggi-do, Republic of Korea<br/>+82-2-390-5114<p class="login_copyright">COPYRIGHT KYONGGI UNIVERSITY. ALL RIGHTS RESERVED.</p>		    </div>
		    <!-- //main_login_copy --> 
    
 		</div>
  		<!-- //main_login_bottom --> 
  
		</div>
		<!-- //main_login_bar -->

	</div>
	<!-- //main_login_bg --> 

	<!-- main_login_right-->
	<div class="main_login_right"> 
	  
	 	<!-- main_login_link -->
	  		  
	  	<!-- main_login_list_03 -->
	  	<div class="main_login_list main_login_notice"> 
	    
		    <!-- main_list_tab -->
		    <div class="main_list_tab">
		      	<p class="main_more"> <a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=1" id="board_more">더보기</a> </p>
		      	<ul class="nav nav-tabs">
		        	<li class="active"><a href="#ubboard_latest_notice" data-toggle="tab" class="notice_more_view">Announcements</a></li>
		        	<li class=""><a href="#ubboard_latest_qna" data-toggle="tab" class="qna_more_view">Q&A</a></li>
		      	</ul>
		      	<div class="tab-content">
		        	<div class="tab-pane active" id="ubboard_latest_notice">
		          		<ul class="board_article">
		            		<li><a href="https://lms.kyonggi.ac.kr/mod/ubboard/article.php?id=1&amp;bwid=394317" class="first">ㆍ<span class="title">[전산정보원] 2023년 11월 11일 서버 정기점검 및 전기 안전점검(정전)에 따른 LMS 홈페이지 접속 안내	</span></a><div class="first_article">안녕하세요.원격교육지원센터입니다.전산정보원에서 11월 서버 정기점검 및 침해사...</div></li><li><a href="https://lms.kyonggi.ac.kr/mod/ubboard/article.php?id=1&amp;bwid=377655" class="">ㆍ<span class="title">[전산정보원] 2023년 7월 22일 서버 정기점검 및 전기 안전점검(정전)에 따른 LMS 홈페이지 접속 안내	</span></a></li><li><a href="https://lms.kyonggi.ac.kr/mod/ubboard/article.php?id=1&amp;bwid=375305" class="">ㆍ<span class="title">[전산정보원] 2023년 6월 17일 서버 정기점검에 따른 LMS 홈페이지 접속 안내	</span></a></li><li><a href="https://lms.kyonggi.ac.kr/mod/ubboard/article.php?id=1&amp;bwid=373663" class="">ㆍ<span class="title">2023년 1학기 LMS 및 원격수업인프라구축 설문조사 안내	</span></a></li><li><a href="https://lms.kyonggi.ac.kr/mod/ubboard/article.php?id=1&amp;bwid=367218" class="">ㆍ<span class="title">[전산정보원] 2023년 5월 20일 서버 정기점검에 따른 LMS 홈페이지 접속 안내	</span></a></li>		          		</ul>
		        	</div>
		        	<div class="tab-pane" id="ubboard_latest_qna">
		          		<ul class="board_article">
		            	<li>No posts</li>		          		</ul>
		        	</div>
		      	</div>
		    </div>
		    <!-- //main_list_tab --> 
  		</div>
  		<!-- //main_login_list_03 --> 
		
		
		<!-- 이용안내 및 관려사이트 -->
	  	<div class="main_login_info">     
		    <!-- 이용안내 -->
		    <p class="info_title">Guide</p>
		    <div class="info_use">
		      	<ul>
		        	<li><a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=1">Announcements</a></li>
		        	<li><a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=2">Q&A</a></li>
		        	<li><a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=3">FAQ</a></li>
		        	<li><a href="https://lms.kyonggi.ac.kr/local/ubion/manual/">Manual</a></li>
		      	</ul>
		    </div>
		    
		    <!-- 관련 사이트 -->
		    <p class="info_title">Related Site</p>
		    <div class="related_site">
		      	<ul>
		        	<li><a href="https://ctl.kyonggi.ac.kr/" target="_blank">CTL</a></li>
		        	<li><a href="https://barun.kyonggi.ac.kr/" target="_blank">Extracurricular Program</a></li>
		        	<li><a href="http://ocw.kyonggi.ac.kr/" target="_blank">OCW</a></li>
		        	<li><a href="http://www.kyonggi.ac.kr/KyonggiUp.kgu" target="_blank">KYOUNGGI UNV.</a></li>
		        	<li><a href="http://lms.kyonggi.ac.kr/local/ubonline/intro.php" target="_blank">KG-MOOC</a></li>
		        	<li><a href="https://lc.multicampus.com/univforu/" target="_blank">LC Mulicampus</a></li>
					<li><a title="Remote Learning Support Center" href="http://smart.kyonggi.ac.kr/" target="_blank">Remote Learning Support Center</a></li>
		      	</ul>
		    </div>
	  	</div>




	</div>

<!-- //main_login_right -->

</div>
<!-- //main_login_wrapper --></div>		</div>
	</div>	
</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.5.1/js/iziModal.min.js"></script>

<script type="text/javascript" src="https://s3.ap-northeast-2.amazonaws.com/code.coursemos.co.kr/flexiblepage_cm32.js?v=0.10"></script>
<script type="text/javascript" src="https://s3.ap-northeast-2.amazonaws.com/code.coursemos.co.kr/annote_supporter.js?v=0.01"></script>



<script type="text/javascript" src="http://la.kyonggi.ac.kr/activeChecker/lms"></script><script type="text/javascript">
//<![CDATA[
var require = {
    baseUrl : 'https://lms.kyonggi.ac.kr/lib/requirejs.php/1693408461/',
    // We only support AMD modules with an explicit define() statement.
    enforceDefine: true,
    skipDataMain: true,
    waitSeconds : 0,

    paths: {
        jquery: 'https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/jquery/jquery-1.11.2.min',
        jqueryui: 'https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/jquery/ui-1.12.1/jquery-ui.min',
        jqueryprivate: 'https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/requirejs/jquery-private'
    },

    // Custom jquery config map.
    map: {
      // '*' means all modules will get 'jqueryprivate'
      // for their 'jquery' dependency.
      '*': { jquery: 'jqueryprivate' },

      // 'jquery-private' wants the real jQuery module
      // though. If this line was not here, there would
      // be an unresolvable cyclic dependency.
      jqueryprivate: { jquery: 'jquery' }
    }
};

//]]>
</script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/requirejs/require.min.js"></script>
<script type="text/javascript">
//<![CDATA[
require(['core/first'], function() {
;
require(["media_videojs/loader"], function(loader) {
    loader.setUp(function(videojs) {
        videojs.options.flash.swf = "https://lms.kyonggi.ac.kr/media/player/videojs/videojs/video-js.swf";
videojs.addLanguage("en",{
 "Play": "Play",
 "Pause": "Pause",
 "Current Time": "Current Time",
 "Duration Time": "Duration Time",
 "Remaining Time": "Remaining Time",
 "Stream Type": "Stream Type",
 "LIVE": "LIVE",
 "Loaded": "Loaded",
 "Progress": "Progress",
 "Fullscreen": "Fullscreen",
 "Non-Fullscreen": "Non-Fullscreen",
 "Mute": "Mute",
 "Unmute": "Unmute",
 "Playback Rate": "Playback Rate",
 "Subtitles": "Subtitles",
 "subtitles off": "subtitles off",
 "Captions": "Captions",
 "captions off": "captions off",
 "Chapters": "Chapters",
 "Close Modal Dialog": "Close Modal Dialog",
 "Descriptions": "Descriptions",
 "descriptions off": "descriptions off",
 "Audio Track": "Audio Track",
 "You aborted the media playback": "You aborted the media playback",
 "A network error caused the media download to fail part-way.": "A network error caused the media download to fail part-way.",
 "The media could not be loaded, either because the server or network failed or because the format is not supported.": "The media could not be loaded, either because the server or network failed or because the format is not supported.",
 "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.": "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.",
 "No compatible source was found for this media.": "No compatible source was found for this media.",
 "The media is encrypted and we do not have the keys to decrypt it.": "The media is encrypted and we do not have the keys to decrypt it.",
 "Play Video": "Play Video",
 "Close": "Close",
 "Modal Window": "Modal Window",
 "This is a modal window": "This is a modal window",
 "This modal can be closed by pressing the Escape key or activating the close button.": "This modal can be closed by pressing the Escape key or activating the close button.",
 ", opens captions settings dialog": ", opens captions settings dialog",
 ", opens subtitles settings dialog": ", opens subtitles settings dialog",
 ", opens descriptions settings dialog": ", opens descriptions settings dialog",
 ", selected": ", selected"
});

    });
});;

require(['core/yui'], function(Y) {
    M.util.init_skiplink(Y);
});
;
require(["core/notification"], function(amd) { amd.init(1, []); });;
require(["core/log"], function(amd) { amd.setConfig({"level":"warn"}); });
});
//]]>
</script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/javascript.php/coursemosv2/1693408461/footer"></script>
<script type="text/javascript">
//<![CDATA[
M.str = {"moodle":{"lastmodified":"Last modified","name":"Name","error":"Error","info":"Information","yes":"Yes","no":"No","morehelp":"More help","loadinghelp":"Loading...","cancel":"Cancel","confirm":"Confirm","areyousure":"Are you sure?","closebuttontitle":"Close","unknownerror":"Unknown error"},"repository":{"type":"Type","size":"Size","invalidjson":"Invalid JSON string","nofilesattached":"No files attached","filepicker":"File picker","logout":"Logout","nofilesavailable":"No files available","norepositoriesavailable":"Sorry, none of your current repositories can return files in the required format.","fileexistsdialogheader":"File exists","fileexistsdialog_editor":"A file with that name has already been attached to the text you are editing.","fileexistsdialog_filemanager":"A file with that name has already been attached","renameto":"Rename to \"{$a}\"","referencesexist":"There are {$a} alias\/shortcut files that use this file as their source","select":"Select"},"admin":{"confirmdeletecomments":"You are about to delete comments, are you sure?","confirmation":"Confirmation"}};
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
(function() {setTimeout("fix_column_widths()", 20);
M.util.help_popups.setup(Y);
Y.use("moodle-core-popuphelp",function() {M.core.init_popuphelp();
});
 M.util.js_pending('random655313b0cb1d72'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random655313b0cb1d72'); });
})();
//]]>
</script>
</body>
</html>