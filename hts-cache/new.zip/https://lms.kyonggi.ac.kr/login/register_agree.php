<!DOCTYPE html>
<html  dir="ltr" lang="en" xml:lang="en">
<head>
    <title>경기대학교 LMS</title>
    <link rel="shortcut icon" href="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme/1693408461/favicon" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, Sign Up" />
<link rel="stylesheet" type="text/css" href="https://lms.kyonggi.ac.kr/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.css" /><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="https://lms.kyonggi.ac.kr/theme/styles.php/coursemosv2/1693408461/all" />
<script type="text/javascript">
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"https:\/\/lms.kyonggi.ac.kr","sesskey":"48Ols5IkKh","loadingicon":"https:\/\/lms.kyonggi.ac.kr\/theme\/image.php\/coursemosv2\/core\/1693408461\/i\/loading_small","themerev":"1693408461","slasharguments":1,"theme":"coursemosv2","jsrev":"1693408461","admin":"admin","svgicons":true};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''}
if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else{me.path=component+'/'+component+'.'+me.type}};
YUI_config = {"debug":false,"base":"https:\/\/lms.kyonggi.ac.kr\/lib\/yuilib\/3.17.2\/","comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"https:\/\/lms.kyonggi.ac.kr\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?m\/1693408461\/","combine":true,"comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","ext":false,"root":"m\/1693408461\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-core-checknet":{"requires":["base-base","moodle-core-notification-alert","io-base"]},"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-dock":{"requires":["base","node","event-custom","event-mouseenter","event-resize","escape","moodle-core-dock-loader","moodle-core-event"]},"moodle-core-dock-loader":{"requires":["escape"]},"moodle-core-dragdrop":{"requires":["base","node","io","dom","dd","event-key","event-focus","moodle-core-notification"]},"moodle-core-event":{"requires":["event-custom"]},"moodle-core-formautosubmit":{"requires":["base","event-key"]},"moodle-core-formchangechecker":{"requires":["base","event-focus","moodle-core-event"]},"moodle-core-handlebars":{"condition":{"trigger":"handlebars","when":"after"}},"moodle-core-languninstallconfirm":{"requires":["base","node","moodle-core-notification-confirm","moodle-core-notification-alert"]},"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core-maintenancemodetimer":{"requires":["base","node"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","escape","event-key","dd-plugin","moodle-core-widget-focusafterclose","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-popuphelp":{"requires":["moodle-core-tooltip"]},"moodle-core-tooltip":{"requires":["base","node","io-base","moodle-core-notification-dialogue","json-parse","widget-position","widget-position-align","event-outside","cache-base"]},"moodle-core_availability-form":{"requires":["base","node","event","event-delegate","panel","moodle-core-notification-dialogue","json"]},"moodle-backup-backupselectall":{"requires":["node","event","node-event-simulate","anim"]},"moodle-backup-confirmcancel":{"requires":["node","node-event-simulate","moodle-core-notification-confirm"]},"moodle-calendar-info":{"requires":["base","node","event-mouseenter","event-key","overlay","moodle-calendar-info-skin"]},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-course-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-course-coursebase","moodle-course-util"]},"moodle-course-formatchooser":{"requires":["base","node","node-event-simulate"]},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-course-modchooser":{"requires":["moodle-core-chooserdialogue","moodle-course-coursebase"]},"moodle-course-toolboxes":{"requires":["node","base","event-key","node","io","moodle-course-coursebase","moodle-course-util"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-form-dateselector":{"requires":["base","node","overlay","calendar"]},"moodle-form-passwordunmask":{"requires":[]},"moodle-form-shortforms":{"requires":["node","base","selector-css3","moodle-core-event"]},"moodle-form-showadvanced":{"requires":["node","base","selector-css3"]},"moodle-core_message-messenger":{"requires":["escape","handlebars","io-base","moodle-core-notification-ajaxexception","moodle-core-notification-alert","moodle-core-notification-dialogue","moodle-core-notification-exception"]},"moodle-question-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-question-preview":{"requires":["base","dom","event-delegate","event-key","core_question_engine"]},"moodle-question-qbankmanager":{"requires":["node","selector-css3"]},"moodle-question-searchform":{"requires":["base","node"]},"moodle-availability_completion-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_date-form":{"requires":["base","node","event","io","moodle-core_availability-form"]},"moodle-availability_grade-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_group-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_grouping-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_profile-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-qtype_ddimageortext-dd":{"requires":["node","dd","dd-drop","dd-constrain"]},"moodle-qtype_ddimageortext-form":{"requires":["moodle-qtype_ddimageortext-dd","form_filepicker"]},"moodle-qtype_ddmarker-dd":{"requires":["node","event-resize","dd","dd-drop","dd-constrain","graphics"]},"moodle-qtype_ddmarker-form":{"requires":["moodle-qtype_ddmarker-dd","form_filepicker","graphics","escape"]},"moodle-qtype_ddwtos-dd":{"requires":["node","dd","dd-drop","dd-constrain"]},"moodle-qtype_stack-input":{"requires":["node","event-valuechange","moodle-core-event","io","json-parse"]},"moodle-mod_assign-history":{"requires":["node","transition"]},"moodle-mod_forum-subscriptiontoggle":{"requires":["base-base","io-base"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form"]},"moodle-mod_quiz-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-base","moodle-mod_quiz-util-page","moodle-mod_quiz-util-slot","moodle-course-util"]},"moodle-mod_quiz-modform":{"requires":["base","node","event"]},"moodle-mod_quiz-questionchooser":{"requires":["moodle-core-chooserdialogue","moodle-mod_quiz-util","querystring-parse"]},"moodle-mod_quiz-quizbase":{"requires":["base","node"]},"moodle-mod_quiz-quizquestionbank":{"requires":["base","event","node","io","io-form","yui-later","moodle-question-qbankmanager","moodle-core-notification-dialogue"]},"moodle-mod_quiz-randomquestion":{"requires":["base","event","node","io","moodle-core-notification-dialogue"]},"moodle-mod_quiz-repaginate":{"requires":["base","event","node","io","moodle-core-notification-dialogue"]},"moodle-mod_quiz-toolboxes":{"requires":["base","node","event","event-key","io","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-slot","moodle-core-notification-ajaxexception"]},"moodle-mod_quiz-util":{"requires":["node","moodle-core-actionmenu"],"use":["moodle-mod_quiz-util-base"],"submodules":{"moodle-mod_quiz-util-base":{},"moodle-mod_quiz-util-slot":{"requires":["node","moodle-mod_quiz-util-base"]},"moodle-mod_quiz-util-page":{"requires":["node","moodle-mod_quiz-util-base"]}}},"moodle-message_airnotifier-toolboxes":{"requires":["base","node","io"]},"moodle-block_navigation-navigation":{"requires":["base","io-base","node","event-synthetic","event-delegate","json-parse"]},"moodle-filter_glossary-autolinker":{"requires":["base","node","io-base","json-parse","event-delegate","overlay","moodle-core-event","moodle-core-notification-alert","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-filter_mathjaxloader-loader":{"requires":["moodle-core-event"]},"moodle-editor_atto-editor":{"requires":["node","transition","io","overlay","escape","event","event-simulate","event-custom","node-event-html5","node-event-simulate","yui-throttle","moodle-core-notification-dialogue","moodle-core-notification-confirm","moodle-editor_atto-rangy","handlebars","timers","querystring-stringify"]},"moodle-editor_atto-plugin":{"requires":["node","base","escape","event","event-outside","handlebars","event-custom","timers","moodle-editor_atto-menu"]},"moodle-editor_atto-menu":{"requires":["moodle-core-notification-dialogue","node","event","event-custom"]},"moodle-editor_atto-rangy":{"requires":[]},"moodle-report_eventlist-eventfilter":{"requires":["base","event","node","node-event-delegate","datatable","autocomplete","autocomplete-filters"]},"moodle-report_loglive-fetchlogs":{"requires":["base","event","node","io","node-event-delegate"]},"moodle-gradereport_grader-gradereporttable":{"requires":["base","node","event","handlebars","overlay","event-hover"]},"moodle-gradereport_history-userselector":{"requires":["escape","event-delegate","event-key","handlebars","io-base","json-parse","moodle-core-notification-dialogue"]},"moodle-tool_capability-search":{"requires":["base","node"]},"moodle-tool_lp-dragdrop-reorder":{"requires":["moodle-core-dragdrop"]},"moodle-tool_monitor-dropdown":{"requires":["base","event","node"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","event-resize","transition","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-atto_accessibilitychecker-button":{"requires":["color-base","moodle-editor_atto-plugin"]},"moodle-atto_accessibilityhelper-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_align-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_bold-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_charmap-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_clear-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_collapse-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_coursemosvimeo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emoticon-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_equation-button":{"requires":["moodle-editor_atto-plugin","moodle-core-event","io","event-valuechange","tabview","array-extras"]},"moodle-atto_html-button":{"requires":["moodle-editor_atto-plugin","event-valuechange"]},"moodle-atto_image-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_indent-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_italic-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_link-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-usedfiles":{"requires":["node","escape"]},"moodle-atto_media-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_noautolink-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_orderedlist-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_pasteimage-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_pbltemplate-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_poodll-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_rtl-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_strike-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_subscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_superscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_table-button":{"requires":["moodle-editor_atto-plugin","moodle-editor_atto-menu","event","event-valuechange"]},"moodle-atto_title-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_underline-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_undo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_unorderedlist-button":{"requires":["moodle-editor_atto-plugin"]}}},"gallery":{"name":"gallery","base":"https:\/\/lms.kyonggi.ac.kr\/lib\/yuilib\/gallery\/","combine":true,"comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","ext":false,"root":"gallery\/1693408461\/","patterns":{"gallery-":{"group":"gallery"}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"https:\/\/lms.kyonggi.ac.kr\/lib\/javascript.php\/1693408461\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker"]},"core_comment":{"name":"core_comment","fullpath":"https:\/\/lms.kyonggi.ac.kr\/lib\/javascript.php\/1693408461\/comment\/comment.js","requires":["base","io-base","node","json","yui2-animation","overlay","escape"]}}};
M.yui.loader = {modules: {}};

//]]>
</script>

<meta property="og:type" content="website" />
<meta property="og:title" content="경기대학교 학습관리시스템" />
<meta property="og:description" content="KYONGGI University, Center for Teaching and Learning" />
<meta property="og:image" content="null" />
<meta property="og:url" content="http://lms.kyonggi.ac.kr" />

<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.5.1/css/iziModal.min.css">


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-5JX2E4WFHT"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-5JX2E4WFHT');
</script><meta name="robots" content="noindex" />    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, target-densitydpi=medium-dpi, minimal-ui" />
    
</head>

<body  id="page-login-register_agree" class="format-site  path-login dir-ltr lang-en yui-skin-sam yui3-skin-sam lms-kyonggi-ac-kr pagelayout-register course-1 context-1 notloggedin coursemos-layout-register content-only">
	<div class="skiplinks">
    <a href="#maincontent" class="skip">Skip to main content</a>
</div><script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.js&amp;rollup/1693408461/mcore-min.js"></script><script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/core/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/core/ui-1.12.1/jquery-ui.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/bootstrap.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.cookie.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.validate.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.validate.methods.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.tableHeadFixer.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery-sortable.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/moment.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/fullcalendar.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/gcal.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.filedownload.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/timer.jquery.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.validate.en.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.headroom.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/javascript-static.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/javascript.php/coursemosv2/1693408461/head"></script>
<script type="text/javascript">
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>

	<script type="text/javascript">
		theme_coursemosv2.lang = 'en';
    </script>
	<div id="page" class="page-nosubmenu">
		<div id="page-header">
			<nav class="navbar navbar-default navbar-fixed-top headroom">
	<div class="container-fluid">
		<div class="navbar-brand">
			<a href="https://lms.kyonggi.ac.kr" class="logo"><span class="sr-only">CyberCampus</span></a>
		</div>
		
		<div class="usermenu">
		<ul class="nav nav-pills" role="tablist"><li role="presentation" class="active user-login"><a href="https://lms.kyonggi.ac.kr/login/index.php" class="btn btn-person">Log in</a></li></ul>		</div>
		
		<div class="coursename"><h1>&nbsp;</h1></div>	</div>
</nav>		</div>
		
		<div id="page-mask">
			<div id="page-container" class="">
				<div id="page-content" class="clearfix">
					<div id="page-content-wrap">
						<div class="page-content-navigation"><ol class=breadcrumb><li class="breadcrumb-home"><a href="https://lms.kyonggi.ac.kr"><img src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme_coursemosv2/1693408461/layout/course-home" alt="HOME" /></a></li><li><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="https://lms.kyonggi.ac.kr/login/register_agree.php"><span itemprop="title">Sign Up</span></a></span></li></ol></div>						<div id="region-main">
							<span class="notifications" id="user-notifications"></span><div role="main"><span id="maincontent"></span><h2>Sign Up</h2><div class="ubregister ubregister_agree">

	<form action="https://lms.kyonggi.ac.kr/login/register.php" method="post" id="register_agree" class="well">
		<h4 class="title">이용약관</h4>
		<div class="agree_box">
			<div class="agree_box_content">
				<pre>
제 1 장   총  칙

제 1 조 (목적)
이 약관은 경기대학교에서 제공하는 KG-MOOC의 이용조건, 절차 및 기타 필요한 사항을 규정함을 목적으로 합니다.

제 2 조 (약관의 효력)
1. 이 약관은 경기대학교 홈페이지(http://www.kyonggi.ac.kr)에 공지하거나 전자우편 등의 방법으로 회원에게 통지함으로써 효력을 발생합니다.
2. 경기대학교는 이 약관의 내용을 변경할 수 있으며, 변경된 약관은 제1항과 같은 방법으로 공지 또는 통지함으로써 효력을 발생합니다.
3. 회원은 변경된 규칙에 동의하지 않을 경우 회원 탈퇴를 요청할 수 있으며, 변경된 규칙의 효력 발생일 이후의 계속적인 서비스 이용은 변경된 규칙에 대한 동의로 간주합니다.

제 3 조 (약관 이외의 준칙)
이 약관에 명시되지 않은 사항이 전기통신기본법, 전기통신사업법, 기타 관련법령에 규정되어 있는 경우 그 규정에 따릅니다.

제 4 조 (용어의 정의)
이 약관에서 사용하는 용어의 정의는 다음과 같습니다.
1. 회원 : 경기대학교와 서비스 이용계약을 체결하고 이용자 아이디(ID)를 부여 받은 자를 말합니다.
2. 아이디(ID) : 회원 식별과 회원의 서비스 이용을 위하여 회원이 결정하고 경기대학교가 승인하는 문자와 숫자의 조합을 말합니다(이하 "ID"라 합니다).
3. 비밀번호 : 회원이 부여 받은 ID와 일치된 회원임을 확인하고, 회원 자신의 비밀을 보호하기 위해 회원이 정한 문자와 숫자의 조합을 말합니다.
4. 전자우편(e-Mail) : 인터넷을 통한 우편을 말합니다.
5. 해지 : 경기대학교 또는 회원이 서비스 이용 이후 그 이용계약을 종료 시키는 의사 표시제를 말합니다.
6. 교육과정 : 경기대학교가 인터넷 통신 기반기술을 이용하여 KG-MOOC 수강 희망자에게 제공하는 교육 컨텐츠를 말합니다.
7. 수강승인 : 회원의 수강신청에 대하여 경기대학교가 정한 요건을 충족시킨 경우 수강 신청자가 정상적으로 교육 서비스를 이용할 수 있도록 승인하는 것을 의미합니다.

제 2 장   서비스 이용계약

제 5 조 (이용계약의 성립)
이용계약은 서비스 이용신청자의 이용신청에 대하여 경기대학교가 허락하고 이용신청자가 약관 내용에 동의함으로써 성립합니다.

제 6 조 (이용신청)
1. 서비스 이용신청자는 서비스를 통하여 소정의 양식에 이용신청자의 정보를 기록해야 합니다.
2. 서비스 이용신청자는 반드시 실명으로 이용신청을 하여야 하며, 1개의 ID만 신청을 할 수 있습니다.

제 7 조 (이용신청의 승낙)
1. 경기대학교는 제6조에 따른 이용신청에 대하여 특별한 사정이 없는 한 접수순서에 따라서 이용신청을 승낙합니다.
2. 경기대학교가 이용신청을 승낙하는 경우 회원에 대하여 서비스를 통하여 다음 각 호의 사항을 통지합니다
① 아이디(ID)
② 회원의 책임, 의무 및 권익보호 등에 관한 사항
3. 경기대학교는 다음 각 호의 1에 해당하는 경우 이용신청에 대한 승낙을 제한할 수 있고, 그 사유가 해소될 까지 승낙을 유보할 수 있습니다.
① 서비스 관련 설비의 용량이 부족한 경우
② 기술상 장애 사유가 있는 경우
③ 기타 경기대학교가 필요하다고 인정되는 경우
4. 경기대학교는 다음 각 호의 1에 해당하는 사항을 인지하는 경우 동 이용신청을 승낙하지 아니합니다.
① 이름이 실명이 아닌 경우
② 다른 사람의 명의를 사용하여 신청한 경우
③ 가입신청서의 내용을 허위로 기재한 경우
④ 사회의 안녕질서 또는 미풍양속을 저해할 목적으로 신청한 경우
⑤ 기타 경기대학교 소정의 이용신청요건을 충족하지 못하는 경우
5. 제3항 또는 제4항에 의하여 이용신청의 승낙을 유보하거나 승낙하지 아니하는 경우, 경기대학교는 이를 이용신청자에 알려야 합니다. 다만, 경기대학교의 귀책사유 없이 이용신청자에게 통지할 수 없는 경우는 예외로 합니다.

제 8 조 (회원 아이디(ID)의 변경)
다음 각 호의 1에 해당하는 경우 경기대학교는 직권 또는 회원의 신청에 의하여 회원 아이디(ID)를 변경할 수 있습니다.
① 회원 아이디(ID)가 회원의 전화번호 등으로 등록되어 있어서 회원의 사생활을 침해할 우려가 있는 경우
② 타인에게 혐오감을 주거나 미풍양속에 어긋나는 경우
③ 기타 소정의 합리적인 사유가 있는 경우

제9조 (쿠키에 의한 개인정보 수집)
1. 경기대학교는 이용자마다 특화된 서비스를 제공하기 위해 이용자 개인용 컴퓨터에 쿠키를 전송합니다.
2. 이용자가 한 번의 로그인으로 편리하게 이용하기 위해서는 쿠키 수신을 허용해야 합니다.
3. 쿠키는 홈페이지를 방문하는 이용자의 특성을 파악하기 위해 사용됩니다.
4. 이용자는 웹브라우저에 있는 옵션기능을 조정하여 쿠키를 선택적으로 받아들일 수 있습니다. 쿠키 수신을 거부할 경우 로그인이 필요한 서비스를 이용할 수 없습니다.

제 3 장  서비스 제공 및 이용

제 10 조 (서비스의 개시)
서비스는 경기대학교가 제7조에 따라서 이용 신청을 승낙한 때부터 즉시 개시됩니다. 다만, 경기대학교의 업무상 또는 기술상의 장애로 인하여 서비스를 즉시 개시하지 못하는 경우 경기대학교는 회원에게 이를 지체 없이 통지합니다.

제 11 조 (서비스 이용시간)
1. 서비스는 경기대학교의 업무상 또는 기술상 장애, 기타 특별한 사유가 없는 한 연중무휴, 1일 24시간 이용할 수 있습니다. 다만 설비의 점검 등 필요한 경우 또는 설비의 장애, 서비스 이용의 폭주 등 불가항력 사항으로 인하여 서비스 이용에 지장이 있는 경우 예외적으로 서비스 이용의 전부 또는 일부에 대하여 제한할 수 있습니다.
2. 경기대학교는 제공하는 서비스 중 일부에 대한 서비스 이용시간을 별도로 정할 수 있으며, 이 경우 그 이용시간을 사전에 회원에게 공지 또는 통지합니다.

제 4장 서비스와 관련한 권리•의무관계

제 12 조 (경기대학교의 의무)
1. 경기대학교는 제12조에서 정한 경우를 제외하고 이 약관에서 정한 바에 따라 계속적, 안정적으로 서비스를 제공할 수 있도록 최선의 노력을 다하여야 합니다.
2. 경기대학교는 서비스에 관련된 설비를 항상 운용할 수 있는 상태로 유지 보수하고, 장애가 발생하는 경우 지체 없이 이를 수리•복구할 수 있도록 최선의 노력을 다하여야 합니다.
3. 경기대학교는 서비스와 관련한 회원의 불만사항이 접수되는 경우 이를 즉시 처리하여야 하며, 즉시 처리가 곤란한 경우 그 사유와 처리일정을 서비스 또는 전자우편을 통하여 동 회원에게 통지하여야 합니다.
4. 경기대학교는 법령과 이 약관이 금지하거나 미풍양속에 반하는 행위를 하지 않으며 이 약관이 정하는 바에 따라 지속적이고, 안정적으로 서비스를 제공하는 데 최선을 다하여야 합니다.
5. 경기대학교는 항상 회원의 신용정보를 포함한 개인신상정보의 보안에 대하여 기술적 안전 조치를 강구하고 관리에 만전을 기함으로서 회원의 정보보안에 최선을 다하여야 합니다.
6. 경기대학교는 회원의 건의사항이나 불만사항을 접수하기 위한 "FAQ"메뉴를 운영하며, 질문에 대한 응답을 신속하게 처리하여야 합니다.
7. 경기대학교는 공정하고 건전한 운영을 통하여 전자상거래 질서 유지에 최선을 다하고, 지속적인 연구, 개발을 통하여 양질의 서비스를 제공함으로써 고객만족을 극대화하여 인터넷 비즈니스 발전에 기여하도록 노력합니다.

제 13 조 (개인정보보호)
1. 경기대학교는 이용자의 정보수집 시 서비스의 제공에 필요한 최소한의 정보를 수집합니다. 다음 사항을 필수사항으로 하며 그 외 사항은 선택사항으로 합니다.
① 성명
② 희망ID(회원의 경우)
③ 비밀번호(회원의 경우)
④ e-Mail 주소
⑤ 생년월일
2. 제공된 개인정보는 당해 이용자의 동의 없이 목적 외의 이용이나 제3자에게 제공할 수 없으며, 이에 대한 모든 책임은 경기대학교가 집니다. 다만, 다음의 경우에는 예외로 합니다.
① 통계작성, 학술연구 또는 시장조사를 위하여 필요한 경우로서 특정 개인을 식별할 수 없는 형태로 제공하는 경우
② 전기통신기본법 등 법률의 규정에 의해 국가기관의 요구가 있는 경우
③ 범죄에 대한 수사상의 목적이 있거나 정보통신윤리위원회의 요청이 있는 경우
④ 기타 관계법령에서 정한 절차에 따른 요청이 있는 경우
⑤ 외부 제휴사이트의 원격교육과정을 수강 신청하는 경우
3. 이용자는 언제든지 경기대학교가 가지고 있는 자신의 개인정보에 대해 열람 및 오류정정을 요구할 수 있으며 경기대학교는 이에 대해 지체 없이 처리합니다. 이용자가 오류의 정정을 요구한 경우에는 경기대학교는 그 오류를 정정할 때까지 당해 개인정보를 이용하지 않습니다.
4. 경기대학교 또는 그로부터 개인정보를 제공받은 제3자는 개인정보의 수집 목적 또는 제공받은 목적을 달성한 때에는 당해 개인정보를 지체 없이 파기합니다.
5. 경기대학교의 개인정보보호에 대한 정책은 홈페이지 "개인 정보보호정책"을 통해 공지하며, 경기대학교는 개인 정보보호를 위한 담당자를 지정하여 관리합니다.

제 14 조 (회원의 의무)
1. 회원은 관계법령, 이 약관의 규정, 이용안내 및 주의사항 등 경기대학교가 통지하는 사항을 준수하여야 하며, 기타 경기대학교의 업무에 방해되는 행위를 하여서는 안 됩니다.
2. 회원은 경기대학교의 사전 승낙 없이 서비스를 이용하여 어떠한 영리 행위도 할 수 없습니다.
3. 회원은 서비스를 이용하여 얻은 정보를 경기대학교의 사전 승낙 없이 복사, 복제, 변경, 번역, 출판•방송 기타의 방법으로 사용하거나 이를 타인에게 제공할 수 없습니다.
4. 회원은 이용신청서의 기재내용 중 변경된 내용이 있는 경우 서비스를 통하여 그 내용을 경기대학교에 통지하여야 합니다.
5. 회원은 서비스 이용과 관련하여 다음 각 호의 행위를 하여서는 안 됩니다.
① 다른 회원의 아이디(ID)를 부정 사용하는 행위
② 범죄행위를 목적으로 하거나 기타 범죄행위와 관련된 행위
③ 선량한 풍속, 기타 사회질서를 해하는 행위
④ 타인의 명예를 훼손하거나 모욕하는 행위
⑤ 타인의 지적재산권 등의 권리를 침해하는 행위
⑥ 해킹행위 또는 컴퓨터바이러스의 유포행위
⑦ 타인의 의사에 반하여 광고성 정보 등 일정한 내용을 지속적으로 전송 또는 타 사이트를 링크하는 행위
⑧ 서비스의 안전적인 운영에 지장을 주거나 줄 우려가 있는 일체의 행위
⑨ 기타 관계법령에 위배되는 행위
⑩ 게시판 등 커뮤니티를 통한 상업적 광고홍보 또는 상거래 행위
제 14 조 (게시물 또는 내용물의 삭제)
경기대학교는 서비스의 게시물 또는 내용물이 제13조의 규정에 위반되거나 경기대학교 소정의 게시기간을 초과하는 경우 사전 통지나 동의 없이 이를 삭제할 수 있습니다.
제 15 조 (게시물에 대한 권리•의무)
게시물에 대한 저작권을 포함한 모든 권리 및 책임은 이를 게시한 회원에게 있습니다.

제 6 장   기  타

제 15 조 (양도금지)
회원이 서비스의 이용권한, 기타 이용 계약상 지위를 타인에게 양도, 증여할 수 없으며, 이를 담보로 제공할 수 없습니다.

제 16 조 (계약해지 및 이용제한)
1. 회원이 이용계약을 해지하고자 하는 때에는 본인이 서비스 또는 전자우편을 통하여 해지하고자 하는 날의 1일전까지(단, 해지일이 법정 공휴일인 경우 공휴일 개시 2일전까지) 이를 경기대학교에 신청하여야 합니다.
2. 경기대학교는 회원이 제24조 약관의 내용을 위반하고, 소정의 기간 이내에 이를 해소하지 아니하는 경우 서비스 이용 계약을 해지할 수 있습니다.
3. 경기대학교는 제2항에 의해 해지 된 회원이 다시 이용신청을 하는 경우 일정기간 그 승낙을 제한할 수 있습니다.

제 17 조 (손해배상)
경기대학교는 제공되는 서비스와 관련하여 회원에게 어떠한 손해가 발생하더라도 동 손해가 경기대학교의 중대한 과실에 의한 경우를 제외하고 이에 대하여 책임을 부담하지 아니합니다.

제 18 조 (면책•배상)
1. 경기대학교는 회원이 서비스에 게재한 정보, 자료, 사실의 정확성, 신뢰성 등 그 내용에 관하여는 어떠한 책임을 부담하지 아니하고, 회원은 자기의 책임아래 서비스를 이용하며, 서비스를 이용하여 게시 또는 전송한 자료 등에 관하여 손해가 발생하거나 자료의 취사선택, 기타서비스 이용과 관련하여 어떠한 불이익이 발생 하더라도 이에 대한 모든 책임은 회원에게 있습니다.
2. 경기대학교는 제24조의 규정에 위반하여 회원간 또는 회원과 제3자간에 서비스를 매개로 하여 물품거래 등과 관련하여 어떠한 책임도 부담하지 아니하고, 회원이 서비스의 이용과 관련하여 기대하는 이익에 관하여 책임을 부담하지 않습니다.
3. 회원 아이디(ID)와 비밀번호의 관리 및 이용상의 부주의로 인하여 발생 되는 손해 또는 제3자에 의한 부정사용 등에 대한 책임은 모두 회원에게 있습니다.
4. 회원이 기타 이 약관의 규정을 위반함으로 인하여 경기대학교가 회원 또는 제3자에 대하여 책임을 부담하게 되고, 이로써 경기대학교에게 손해가 발생하게 되는 경우, 이 약관을 위반한 회원은 경기대학교에게 발생하는 모든 손해를 배상하여야 하며, 동 손해로부터 경기대학교을 면책시켜야 합니다.

제 19 조 (분쟁의 해결)
1. 경기대학교와 회원은 서비스와 관련하여 발생한 분쟁을 원만하게 해결하기 위하여 필요한 모든 노력을 하여야 합니다.
2. 제1항의 규정에도 불구하고 분쟁으로 인하여 소송이 제기될 경우 소송은 경기대학교의 소재지를 관할하는 법원의 관할로 합니다.

제 20 조 (소비자 불만 접수처리)
1. 회원은 경기대학교에 대해서 불만사항이나 문의사항이 있을 경우 홈페이지 나 전자우편, 전화 등을 이용하여 처리 접수를 할 수 있고 경기대학교는 이의 처리를 성실하게 수행합니다.
2. 전자우편주소나 전화번호 등은 홈페이지 상에 공지합니다.

부  칙
제 1 조 (시행일) 이 약관은 2019년 월 일부터 시행합니다.

1. 홈페이지 이용자의 개인정보 수집·관리 목적
홈페이지 이용자의 개인정보를 수집·관리하는 목적은 홈페이지 이용자에게 원활한 서비스를 제공하며 홈페이지의 개선과 보완을 위함입니다.

2. 홈페이지 이용자의 개인정보 수집항목
홈페이지를 통하여 수집·관리하는 개인정보는 아래와 같습니다.
- 이름, 생년월일, 이메일, 연락처, 학습이력, 접속 IP주소

3. 홈페이지 이용자의 개인정보 보호범위
수집된 모든 개인정보가 불법 오용되지 않도록 최선의 노력을 다할 것이며, 이용자의 사전허가 없이는 공개하지 않겠습니다. 또한 [공공기관의 개인정보 보호에 관한 법률] 제10조 이용 및 제공의 제한에 의거하여, 개인정보 제공에 엄격한 제한을 두겠습니다. 다만, 이용자 부주의로 개인정보를 유출하였다면 이에 대하여 책임을 지지 않습니다.

4. 개인정보의 관리 책임
이용자의 ID와 비밀번호의 관리책임은 이용자 개인에게 있습니다. 개인정보가 다른 이에게 유출되지 않도록 주의를 기울여 주십시오.
개인정보의 관리 책임 개인정보 열람 및 변경

5. 개인정보의 처리 및 보유기간
홈페이지를 통해 수집된 개인정보의 보유기간은 가입 후 2년까지이며, 기간 만료시 개인의 재동의를 얻어 개인정보항목의 보유기간을 연장할 수 있습니다.
① 홈페이지 탈퇴 또는 휴먼계정 전환 후 2년까지 보유합니다. 다만, 다음의 
   사유에 해당하는 경우에는 해당 사유 종료 시까지 보유합니다.
  - 관계 법령 위반에 따른 수사·조사 등이 진행 중인 경우에는 해당 수사·조 
    사 종료 시까지
  - 범죄행위를 목적으로 하거나 기타 범죄 행위와 관련된 행위
  - 선량한 풍속, 기타 사회질서를 해하는 행위
② 민원사무 처리 시 민원 처리 종료 후 3년까지 보유합니다.

6. 동의 거부 권리 및 그에 따른 불이익
개인정보의 수집·이용목적에 대한 동의를 거부할 수 있으며, 동의 거부 시 홈페이지에 회원가입이 되지 않으며, 제공하는 서비스에 제한을 받을 수 있습니다.

				</pre>
			</div>
		</div>
		<div class="checkbox">
			<label class="text-danger">
				<input type="checkbox" name="clause" value="1" /> 이용약관 내용을 확인했으며 약관에 동의합니다.			</label>
		</div>

		<hr />

		<h4 class="title">개인정보 수집 및 이용</h4>
		<div class="agree_box">
			<div class="agree_box_content">
				<pre>
경기대학교는 회원가입, 원활한 고객상담, 각종 서비스 등 기본적인 서비스 제공을 위해 「개인정보보호법」관계법령에 따라 아래와 같이 최소한의 개인정보를 수집하고 있습니다. 
(선택항목의 입력 여부에 관계없이) 필수항목을 입력하지 않으시는 경우 회원가입이 불가하며, 아래 사항에 대해 충분히 읽어 보신 후, 동의 여부를 체크·서명하여 주시기 바랍니다.

1.수집항목
[일반 회원]
ㆍ필수항목 : 아이디, 비밀번호, 이름, 영문명, 생년월일
[서비스 이용시 자동 수집 정보]
ㆍ서비스 이용 과정에서 아래와 같은 정보들이 자동으로 생성되어 수집될 수 있습니다.
ㆍIP Address, 쿠키, 방문 일시, 서비스 이용 기록, 불량 이용 기록

2. 개인정보의 수집 이용목적
경기대학교는 이용자의 소중한 개인정보를 다음과 같은 목적으로만 이용하며, 목적이 변경될 경우에는 사전에 이용자의 동의를 구하도록 하겠습니다.
가. 이용자에게 입학 상담과정에서 이용자의 문의사항이나 불만을 처리하고 공지사항 등을 전달하기 위해 사용합니다.

3. 개인정보의 보유 및 이용기간
경기대학교는 이용자의 개인정보를 회원가입을 하는 시점부터 서비스를 제공하는 기간 동안에만 제한적으로 이용하고 있습니다.
이용자가 회원탈퇴를 요청하거나 제공한 개인정보의 수집 및 이용에 대한 동의를 철회하는 경우, 또는 수집 및 이용목적이 달성되거나 보유 및 이용기간이 종료한 경우 해당 이용자의 개인정보는 지체 없이 파기 됩니다.
그리고 관계법령의 규정에 따라 아래와 같이 관계 법령에서 정한 일정한 기간 동안 회원정보를 보관합니다.
ㆍ서비스 이용 관련 개인정보 (로그인기록)보존 근거 : 통신비밀보호법 보존 기간 : 3개월

4. 권리
동의를 거부할 권리가 있으며 그에 따른 동의 거부 시 홈페이지에 회원가입이 되지 않으며, 제공하는 서비스에 제한을 받을 수 있습니다.

				</pre>
			</div>
		</div>
		<div class="checkbox">
			<label class="text-danger">
				<input type="checkbox" name="privacy" value="1" /> 개인정보 수집 및 이용에 동의합니다.			</label>
		</div>
		
		<hr />
		
		<div class="agree_button">
			<button type="submit" class="btn btn-success btn-register">Create my new account</button>
			<button type="button" class="btn btn-default btn-cancel">Cancel</button>
		</div>
	</form>
</div>
</div>				            
			            </div>
		            </div>
				</div>
			</div>
		</div>
		
		<div id="page-footer">
			<ul class="footer-menus pull-left">
		<li><a href="http://www.kyonggi.ac.kr/webService.kgu?menuCode=K00M05020000" target="_blank">Privacy Policy</a></li>
</ul>
<!-- 
<div class="helpdesk">
	<a href="#" class="nobtn">도움말</a>
</div>
 -->
<div class="address">
	154-42, Kyounggi univ., Gwanggyosan-ro, Yeongtong-gu, Suwon-si, Gyeonggi-do, Republic of Korea T.+82-2-390-5114 <br/>
	<span class="copyright">
			</span>
</div>
<div id="back-top">
	<a href="#top"><span></span></a>
</div>
<div id="ajax_loading_submit">&nbsp;</div>
<div id="ajax_loading_container">
	<div id="ajax_loading_submit_img">
		<img src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme_coursemosv2/1693408461/ajax-loader" alt="loading..." /> Loading...
	</div>
	<div id="ajax_loading_message">
		<p class="save_msg">Data is saved. Please wait.</p>
		<p class="refresh_msg">Long period of time, if refresh(F5) while loading page please.</p>
	</div>
</div>	
		</div>
	</div>
	
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.5.1/js/iziModal.min.js"></script>

<script type="text/javascript" src="https://s3.ap-northeast-2.amazonaws.com/code.coursemos.co.kr/flexiblepage_cm32.js?v=0.10"></script>
<script type="text/javascript" src="https://s3.ap-northeast-2.amazonaws.com/code.coursemos.co.kr/annote_supporter.js?v=0.01"></script>



<script type="text/javascript" src="http://la.kyonggi.ac.kr/activeChecker/lms"></script><script type="text/javascript">
//<![CDATA[
var require = {
    baseUrl : 'https://lms.kyonggi.ac.kr/lib/requirejs.php/1693408461/',
    // We only support AMD modules with an explicit define() statement.
    enforceDefine: true,
    skipDataMain: true,
    waitSeconds : 0,

    paths: {
        jquery: 'https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/jquery/jquery-1.11.2.min',
        jqueryui: 'https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/jquery/ui-1.12.1/jquery-ui.min',
        jqueryprivate: 'https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/requirejs/jquery-private'
    },

    // Custom jquery config map.
    map: {
      // '*' means all modules will get 'jqueryprivate'
      // for their 'jquery' dependency.
      '*': { jquery: 'jqueryprivate' },

      // 'jquery-private' wants the real jQuery module
      // though. If this line was not here, there would
      // be an unresolvable cyclic dependency.
      jqueryprivate: { jquery: 'jquery' }
    }
};

//]]>
</script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/requirejs/require.min.js"></script>
<script type="text/javascript">
//<![CDATA[
require(['core/first'], function() {
;
require(["media_videojs/loader"], function(loader) {
    loader.setUp(function(videojs) {
        videojs.options.flash.swf = "https://lms.kyonggi.ac.kr/media/player/videojs/videojs/video-js.swf";
videojs.addLanguage("en",{
 "Play": "Play",
 "Pause": "Pause",
 "Current Time": "Current Time",
 "Duration Time": "Duration Time",
 "Remaining Time": "Remaining Time",
 "Stream Type": "Stream Type",
 "LIVE": "LIVE",
 "Loaded": "Loaded",
 "Progress": "Progress",
 "Fullscreen": "Fullscreen",
 "Non-Fullscreen": "Non-Fullscreen",
 "Mute": "Mute",
 "Unmute": "Unmute",
 "Playback Rate": "Playback Rate",
 "Subtitles": "Subtitles",
 "subtitles off": "subtitles off",
 "Captions": "Captions",
 "captions off": "captions off",
 "Chapters": "Chapters",
 "Close Modal Dialog": "Close Modal Dialog",
 "Descriptions": "Descriptions",
 "descriptions off": "descriptions off",
 "Audio Track": "Audio Track",
 "You aborted the media playback": "You aborted the media playback",
 "A network error caused the media download to fail part-way.": "A network error caused the media download to fail part-way.",
 "The media could not be loaded, either because the server or network failed or because the format is not supported.": "The media could not be loaded, either because the server or network failed or because the format is not supported.",
 "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.": "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.",
 "No compatible source was found for this media.": "No compatible source was found for this media.",
 "The media is encrypted and we do not have the keys to decrypt it.": "The media is encrypted and we do not have the keys to decrypt it.",
 "Play Video": "Play Video",
 "Close": "Close",
 "Modal Window": "Modal Window",
 "This is a modal window": "This is a modal window",
 "This modal can be closed by pressing the Escape key or activating the close button.": "This modal can be closed by pressing the Escape key or activating the close button.",
 ", opens captions settings dialog": ", opens captions settings dialog",
 ", opens subtitles settings dialog": ", opens subtitles settings dialog",
 ", opens descriptions settings dialog": ", opens descriptions settings dialog",
 ", selected": ", selected"
});

    });
});;

require(['core/yui'], function(Y) {
    M.util.init_skiplink(Y);
});
;
require(["core/notification"], function(amd) { amd.init(1, []); });;
require(["core/log"], function(amd) { amd.setConfig({"level":"warn"}); });
});
//]]>
</script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/login/register.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/javascript.php/coursemosv2/1693408461/footer"></script>
<script type="text/javascript">
//<![CDATA[
M.str = {"moodle":{"lastmodified":"Last modified","name":"Name","error":"Error","info":"Information","yes":"Yes","no":"No","morehelp":"More help","loadinghelp":"Loading...","cancel":"Cancel","confirm":"Confirm","areyousure":"Are you sure?","closebuttontitle":"Close","unknownerror":"Unknown error"},"repository":{"type":"Type","size":"Size","invalidjson":"Invalid JSON string","nofilesattached":"No files attached","filepicker":"File picker","logout":"Logout","nofilesavailable":"No files available","norepositoriesavailable":"Sorry, none of your current repositories can return files in the required format.","fileexistsdialogheader":"File exists","fileexistsdialog_editor":"A file with that name has already been attached to the text you are editing.","fileexistsdialog_filemanager":"A file with that name has already been attached","renameto":"Rename to \"{$a}\"","referencesexist":"There are {$a} alias\/shortcut files that use this file as their source","select":"Select"},"admin":{"confirmdeletecomments":"You are about to delete comments, are you sure?","confirmation":"Confirmation"},"local_ubion":{"signup_clause_agree_error":"\ud68c\uc6d0\uc57d\uad00\uc5d0 \ub3d9\uc758\ud558\uc154\uc57c \ud68c\uc6d0\uac00\uc785\uc744 \ud558\uc2e4 \uc218 \uc788\uc2b5\ub2c8\ub2e4.","signup_privacy_agree_error":"\uac1c\uc778\uc815\ubcf4 \uc218\uc9d1 \ubc0f \uc774\uc6a9\uc5d0 \ub3d9\uc758\ud558\uc154\uc57c \ud68c\uc6d0\uac00\uc785\uc744 \ud558\uc2e4 \uc218 \uc788\uc2b5\ub2c8\ub2e4."}};
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
(function() {setTimeout("fix_column_widths()", 20);
M.register.agree(Y, "https:\/\/lms.kyonggi.ac.kr");
M.util.help_popups.setup(Y);
Y.use("moodle-core-popuphelp",function() {M.core.init_popuphelp();
});
 M.util.js_pending('random655313cd1e16f3'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random655313cd1e16f3'); });
})();
//]]>
</script>
</body>
</html>
