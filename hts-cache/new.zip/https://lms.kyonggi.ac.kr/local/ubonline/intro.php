<!DOCTYPE html>
<html  dir="ltr" lang="zh-cn" xml:lang="zh-cn">
<head>
    <title>경기대학교 LMS</title>
    <link rel="shortcut icon" href="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme/1693408461/favicon" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, How to create" />
<link rel="stylesheet" type="text/css" href="https://lms.kyonggi.ac.kr/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.css" /><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="https://lms.kyonggi.ac.kr/theme/styles.php/coursemosv2/1693408461/all" />
<script type="text/javascript">
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"https:\/\/lms.kyonggi.ac.kr","sesskey":"48Ols5IkKh","loadingicon":"https:\/\/lms.kyonggi.ac.kr\/theme\/image.php\/coursemosv2\/core\/1693408461\/i\/loading_small","themerev":"1693408461","slasharguments":1,"theme":"coursemosv2","jsrev":"1693408461","admin":"admin","svgicons":true};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''}
if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else{me.path=component+'/'+component+'.'+me.type}};
YUI_config = {"debug":false,"base":"https:\/\/lms.kyonggi.ac.kr\/lib\/yuilib\/3.17.2\/","comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"https:\/\/lms.kyonggi.ac.kr\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?m\/1693408461\/","combine":true,"comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","ext":false,"root":"m\/1693408461\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-core-checknet":{"requires":["base-base","moodle-core-notification-alert","io-base"]},"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-dock":{"requires":["base","node","event-custom","event-mouseenter","event-resize","escape","moodle-core-dock-loader","moodle-core-event"]},"moodle-core-dock-loader":{"requires":["escape"]},"moodle-core-dragdrop":{"requires":["base","node","io","dom","dd","event-key","event-focus","moodle-core-notification"]},"moodle-core-event":{"requires":["event-custom"]},"moodle-core-formautosubmit":{"requires":["base","event-key"]},"moodle-core-formchangechecker":{"requires":["base","event-focus","moodle-core-event"]},"moodle-core-handlebars":{"condition":{"trigger":"handlebars","when":"after"}},"moodle-core-languninstallconfirm":{"requires":["base","node","moodle-core-notification-confirm","moodle-core-notification-alert"]},"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core-maintenancemodetimer":{"requires":["base","node"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","escape","event-key","dd-plugin","moodle-core-widget-focusafterclose","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-popuphelp":{"requires":["moodle-core-tooltip"]},"moodle-core-tooltip":{"requires":["base","node","io-base","moodle-core-notification-dialogue","json-parse","widget-position","widget-position-align","event-outside","cache-base"]},"moodle-core_availability-form":{"requires":["base","node","event","event-delegate","panel","moodle-core-notification-dialogue","json"]},"moodle-backup-backupselectall":{"requires":["node","event","node-event-simulate","anim"]},"moodle-backup-confirmcancel":{"requires":["node","node-event-simulate","moodle-core-notification-confirm"]},"moodle-calendar-info":{"requires":["base","node","event-mouseenter","event-key","overlay","moodle-calendar-info-skin"]},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-course-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-course-coursebase","moodle-course-util"]},"moodle-course-formatchooser":{"requires":["base","node","node-event-simulate"]},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-course-modchooser":{"requires":["moodle-core-chooserdialogue","moodle-course-coursebase"]},"moodle-course-toolboxes":{"requires":["node","base","event-key","node","io","moodle-course-coursebase","moodle-course-util"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-form-dateselector":{"requires":["base","node","overlay","calendar"]},"moodle-form-passwordunmask":{"requires":[]},"moodle-form-shortforms":{"requires":["node","base","selector-css3","moodle-core-event"]},"moodle-form-showadvanced":{"requires":["node","base","selector-css3"]},"moodle-core_message-messenger":{"requires":["escape","handlebars","io-base","moodle-core-notification-ajaxexception","moodle-core-notification-alert","moodle-core-notification-dialogue","moodle-core-notification-exception"]},"moodle-question-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-question-preview":{"requires":["base","dom","event-delegate","event-key","core_question_engine"]},"moodle-question-qbankmanager":{"requires":["node","selector-css3"]},"moodle-question-searchform":{"requires":["base","node"]},"moodle-availability_completion-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_date-form":{"requires":["base","node","event","io","moodle-core_availability-form"]},"moodle-availability_grade-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_group-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_grouping-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_profile-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-qtype_ddimageortext-dd":{"requires":["node","dd","dd-drop","dd-constrain"]},"moodle-qtype_ddimageortext-form":{"requires":["moodle-qtype_ddimageortext-dd","form_filepicker"]},"moodle-qtype_ddmarker-dd":{"requires":["node","event-resize","dd","dd-drop","dd-constrain","graphics"]},"moodle-qtype_ddmarker-form":{"requires":["moodle-qtype_ddmarker-dd","form_filepicker","graphics","escape"]},"moodle-qtype_ddwtos-dd":{"requires":["node","dd","dd-drop","dd-constrain"]},"moodle-qtype_stack-input":{"requires":["node","event-valuechange","moodle-core-event","io","json-parse"]},"moodle-mod_assign-history":{"requires":["node","transition"]},"moodle-mod_forum-subscriptiontoggle":{"requires":["base-base","io-base"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form"]},"moodle-mod_quiz-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-base","moodle-mod_quiz-util-page","moodle-mod_quiz-util-slot","moodle-course-util"]},"moodle-mod_quiz-modform":{"requires":["base","node","event"]},"moodle-mod_quiz-questionchooser":{"requires":["moodle-core-chooserdialogue","moodle-mod_quiz-util","querystring-parse"]},"moodle-mod_quiz-quizbase":{"requires":["base","node"]},"moodle-mod_quiz-quizquestionbank":{"requires":["base","event","node","io","io-form","yui-later","moodle-question-qbankmanager","moodle-core-notification-dialogue"]},"moodle-mod_quiz-randomquestion":{"requires":["base","event","node","io","moodle-core-notification-dialogue"]},"moodle-mod_quiz-repaginate":{"requires":["base","event","node","io","moodle-core-notification-dialogue"]},"moodle-mod_quiz-toolboxes":{"requires":["base","node","event","event-key","io","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-slot","moodle-core-notification-ajaxexception"]},"moodle-mod_quiz-util":{"requires":["node","moodle-core-actionmenu"],"use":["moodle-mod_quiz-util-base"],"submodules":{"moodle-mod_quiz-util-base":{},"moodle-mod_quiz-util-slot":{"requires":["node","moodle-mod_quiz-util-base"]},"moodle-mod_quiz-util-page":{"requires":["node","moodle-mod_quiz-util-base"]}}},"moodle-message_airnotifier-toolboxes":{"requires":["base","node","io"]},"moodle-block_navigation-navigation":{"requires":["base","io-base","node","event-synthetic","event-delegate","json-parse"]},"moodle-filter_glossary-autolinker":{"requires":["base","node","io-base","json-parse","event-delegate","overlay","moodle-core-event","moodle-core-notification-alert","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-filter_mathjaxloader-loader":{"requires":["moodle-core-event"]},"moodle-editor_atto-editor":{"requires":["node","transition","io","overlay","escape","event","event-simulate","event-custom","node-event-html5","node-event-simulate","yui-throttle","moodle-core-notification-dialogue","moodle-core-notification-confirm","moodle-editor_atto-rangy","handlebars","timers","querystring-stringify"]},"moodle-editor_atto-plugin":{"requires":["node","base","escape","event","event-outside","handlebars","event-custom","timers","moodle-editor_atto-menu"]},"moodle-editor_atto-menu":{"requires":["moodle-core-notification-dialogue","node","event","event-custom"]},"moodle-editor_atto-rangy":{"requires":[]},"moodle-report_eventlist-eventfilter":{"requires":["base","event","node","node-event-delegate","datatable","autocomplete","autocomplete-filters"]},"moodle-report_loglive-fetchlogs":{"requires":["base","event","node","io","node-event-delegate"]},"moodle-gradereport_grader-gradereporttable":{"requires":["base","node","event","handlebars","overlay","event-hover"]},"moodle-gradereport_history-userselector":{"requires":["escape","event-delegate","event-key","handlebars","io-base","json-parse","moodle-core-notification-dialogue"]},"moodle-tool_capability-search":{"requires":["base","node"]},"moodle-tool_lp-dragdrop-reorder":{"requires":["moodle-core-dragdrop"]},"moodle-tool_monitor-dropdown":{"requires":["base","event","node"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","event-resize","transition","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-atto_accessibilitychecker-button":{"requires":["color-base","moodle-editor_atto-plugin"]},"moodle-atto_accessibilityhelper-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_align-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_bold-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_charmap-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_clear-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_collapse-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_coursemosvimeo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emoticon-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_equation-button":{"requires":["moodle-editor_atto-plugin","moodle-core-event","io","event-valuechange","tabview","array-extras"]},"moodle-atto_html-button":{"requires":["moodle-editor_atto-plugin","event-valuechange"]},"moodle-atto_image-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_indent-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_italic-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_link-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-usedfiles":{"requires":["node","escape"]},"moodle-atto_media-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_noautolink-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_orderedlist-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_pasteimage-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_pbltemplate-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_poodll-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_rtl-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_strike-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_subscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_superscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_table-button":{"requires":["moodle-editor_atto-plugin","moodle-editor_atto-menu","event","event-valuechange"]},"moodle-atto_title-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_underline-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_undo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_unorderedlist-button":{"requires":["moodle-editor_atto-plugin"]}}},"gallery":{"name":"gallery","base":"https:\/\/lms.kyonggi.ac.kr\/lib\/yuilib\/gallery\/","combine":true,"comboBase":"https:\/\/lms.kyonggi.ac.kr\/theme\/yui_combo.php?","ext":false,"root":"gallery\/1693408461\/","patterns":{"gallery-":{"group":"gallery"}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"https:\/\/lms.kyonggi.ac.kr\/lib\/javascript.php\/1693408461\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker"]},"core_comment":{"name":"core_comment","fullpath":"https:\/\/lms.kyonggi.ac.kr\/lib\/javascript.php\/1693408461\/comment\/comment.js","requires":["base","io-base","node","json","yui2-animation","overlay","escape"]}}};
M.yui.loader = {modules: {}};

//]]>
</script>

<meta property="og:type" content="website" />
<meta property="og:title" content="경기대학교 학습관리시스템" />
<meta property="og:description" content="KYONGGI University, Center for Teaching and Learning" />
<meta property="og:image" content="null" />
<meta property="og:url" content="http://lms.kyonggi.ac.kr" />

<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/xeicon@2.3.3/xeicon.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.5.1/css/iziModal.min.css">


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-5JX2E4WFHT"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-5JX2E4WFHT');
</script>    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, target-densitydpi=medium-dpi, minimal-ui" />
</head>

<body  id="page-local_ubonline" class="format-site  dir-ltr lang-zh_cn yui-skin-sam yui3-skin-sam lms-kyonggi-ac-kr pagelayout-base course-1 context-1 notloggedin coursemos-layout-course page-xs path-local-ubonline content-only">
	<div class="skiplinks">
    <a href="#maincontent" class="skip">跳到主要内容</a>
</div><script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/yui_combo.php?rollup/3.17.2/yui-moodlesimple-min.js&amp;rollup/1693408461/mcore-min.js"></script><script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/core/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/core/ui-1.12.1/jquery-ui.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/bootstrap.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.cookie.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.validate.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.validate.methods.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.tableHeadFixer.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery-sortable.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/moment.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/fullcalendar.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/gcal.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.filedownload.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/timer.jquery.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.validate.en.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/jquery.php/theme_coursemosv2/jquery.headroom.min.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/javascript-static.js"></script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/javascript.php/coursemosv2/1693408461/head"></script>
<script type="text/javascript">
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>

	<script type="text/javascript">
		theme_coursemosv2.lang = 'zh_cn';
    </script>
	<div id="page" class="">
		<div id="page-header">
			<nav class="navbar navbar-default navbar-fixed-top headroom">
	<div class="container-fluid">
		<div class="navbar-brand">
			<a href="https://lms.kyonggi.ac.kr" class="logo"><span class="sr-only">CyberCampus</span></a>
		</div>
		
		<div class="usermenu">
		<ul class="nav nav-pills" role="tablist"><li role="presentation" class="active user-login"><a href="https://lms.kyonggi.ac.kr/login/index.php" class="btn btn-person">登录</a></li></ul>		</div>
		
		<div class="coursename"><h1>&nbsp;</h1></div>	</div>
</nav>		</div>
		
		<div id="page-lnb">
			<ul class="left-menus">
	<li class=""><a href="https://lms.kyonggi.ac.kr" class="left-menu-link left-menu-link-mypage" title="My Page" data-toggle="tooltip" data-placement="right"><h5 class="">My Page</h5></a><ul><li class=""><a href="https://lms.kyonggi.ac.kr" title="">Dashboard</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/user/files.php" title="">Manage file</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/mod/ubboard/my.php" title="">Notice Board</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/user/edit.php?id=0" title="">Update profile</a></li></ul></li><li class=""><a href="https://lms.kyonggi.ac.kr" class="left-menu-link left-menu-link-mycourses" title="Curriculum" data-toggle="tooltip" data-placement="right"><h5 class="">Curriculum</h5></a><ul><li class=""><a href="https://lms.kyonggi.ac.kr/local/ubion/user/" title="">My Course</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/local/ubassistant/" title="">Assistant/Auditor Request</a></li></ul></li><li class=""><a href="https://lms.kyonggi.ac.kr/local/ubassistant/irregular.php" class="left-menu-link left-menu-link-irrcourse" title="Non-curriculum" data-toggle="tooltip" data-placement="right"><h5 class="nosubmenu">Non-curriculum</h5></a></li><li class="active active-fix"><a href="https://lms.kyonggi.ac.kr/local/ubonline/" class="left-menu-link left-menu-link-online" title="Non-curriculum" data-toggle="tooltip" data-placement="right"><h5 class="">Non-curriculum</h5></a><ul><li class=""><a href="https://lms.kyonggi.ac.kr/local/ubonline/" title="">Enrollment</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/local/ubonline/my.php" title="">My Course</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/local/ubonline/history.php" title="">Completion Check</a></li><li class="active"><a href="https://lms.kyonggi.ac.kr/local/ubonline/intro.php" title="active">How to create</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=55346" title="">KG-MOOC 공지사항</a></li></ul></li><li class=""><a href="https://lms.kyonggi.ac.kr/local/ubeclass/my.php" class="left-menu-link left-menu-link-eclass" title="e-Class" data-toggle="tooltip" data-placement="right"><h5 class="nosubmenu">e-Class</h5></a></li><li class=""><a href="https://lms.kyonggi.ac.kr/local/ubmessage/" class="left-menu-link left-menu-link-message" title="Message" data-toggle="tooltip" data-placement="right"><h5 class="nosubmenu">Message</h5></a></li><li class=""><a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=1" class="left-menu-link left-menu-link-guide" title="Guide" data-toggle="tooltip" data-placement="right"><h5 class="">Guide</h5></a><ul><li class=""><a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=1" title="">Announcements</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=2" title="">Q&A</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=3" title="">FAQ</a></li><li class=""><a href="https://lms.kyonggi.ac.kr/local/ubion/manual/" title="">Manual</a></li><div class="itl_info"><h5>Call us</h5><div class="itl_desc"><p class="tell">031-249-8707</p><p class="name">Center for Teaching and Learning</p></div></div></ul></li></ul>

<ul class="left-menus left-banner active">
<li><a href="https://kgedu.kyonggi.ac.kr/" target="_blank"><div class="itl_info"><div class="itl_desc"><p class="name_1">KG-EDU</p><p class="name_2">법정의무교육</p></div></div></a></li></ul>		</div>
		<div id="page-mask">
						<div id="page-container" class="">
				<div id="page-submenu">
	<div id="coursemos-course-menu">
		<ul class="course-menus">
			
<li>
	<div class="block block-coursemos block-ubonline "  data-name="ubonline">
		<div class="header">
			<div class="block_action">
				<img class="block-hider-hide" alt="Hide block" src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/core/1693408461/t/switch_minus" title="Hide block" />
				<img class="block-hider-show" alt="Show block" src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/core/1693408461/t/switch_plus" title="Show block" />
			</div>
			<h2>Non-curriculum</h2>
		</div>
		<div class="content">
						<ul class="topmenu ubonline_snuon">
				<li class=" none_submenu"><a href="https://lms.kyonggi.ac.kr/local/ubonline/index.php" title="Lecture List" class="" >Lecture List </a></li><li class=" none_submenu"><a href="https://lms.kyonggi.ac.kr/local/ubonline/my.php" title="My Course" class="" >My Course </a></li><li class=" none_submenu"><a href="https://lms.kyonggi.ac.kr/local/ubonline/history.php" title="Completion Check" class="" >Completion Check </a></li><li class="active none_submenu"><a href="https://lms.kyonggi.ac.kr/local/ubonline/intro.php" title="How to create" class="" >How to create </a></li><li class=" none_submenu"><a href="https://lms.kyonggi.ac.kr/mod/ubboard/view.php?id=55346" title="KG-MOOC 공지사항" class="" >KG-MOOC 공지사항 </a></li>			</ul>
		</div>
	</div>
</li>

<li>
	<div class="block block-coursemos block-ubonline-search "  data-name="search">
		<div class="header">
			<div class="block_action">
				<img class="block-hider-hide" alt="Hide block" src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/core/1693408461/t/switch_minus" title="Hide block" />
				<img class="block-hider-show" alt="Show block" src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/core/1693408461/t/switch_plus" title="Show block" />
			</div>
			<h2>강좌 분류</h2>
		</div>
		<div class="content">
			<form method="get" action="/local/ubonline/index.php">
			<ul class="topmenu ubonline">	<li class="expand">		<a href="#">Curriculum<span class="caret"></span></a>		<ul class="ubonline_category">			<li><input type="checkbox" name="ubonline_progress_all" value="1" />Select all</li>		<li title="KG-MOOC"><input type="checkbox" name="ubonline_progress[]" value="11" >KG-MOOC</li>		<li title="Geq"><input type="checkbox" name="ubonline_progress[]" value="12" >Geq</li>		<li title="SPL"><input type="checkbox" name="ubonline_progress[]" value="13" >SPL</li>		<li title="IPP"><input type="checkbox" name="ubonline_progress[]" value="14" >IPP</li>		<li title="Internet/smartphone overdependence prevention education"><input type="checkbox" name="ubonline_progress[]" value="15" >Internet/smartphone ov···</li>		<li title="Suicide Prevention Education"><input type="checkbox" name="ubonline_progress[]" value="16" >Suicide Prevention Edu···</li>		<li title="111"><input type="checkbox" name="ubonline_progress[]" value="17" >111</li>		<li title="P.E"><input type="checkbox" name="ubonline_progress[]" value="18" >P.E</li>		<li title="Research Ethics Curriculum"><input type="checkbox" name="ubonline_progress[]" value="19" >Research Ethics Curric···</li>		<li title="ADM"><input type="checkbox" name="ubonline_progress[]" value="20" >ADM</li>		<li title="SW"><input type="checkbox" name="ubonline_progress[]" value="21" >SW</li>		<li title="IRB"><input type="checkbox" name="ubonline_progress[]" value="22" >IRB</li>		<li title="커리어 메타캠프"><input type="checkbox" name="ubonline_progress[]" value="24" >커리어 메타캠프</li>		<li title="총무팀_긴급지원신고의무교육"><input type="checkbox" name="ubonline_progress[]" value="25" >총무팀_긴급지원신고의···</li>		<li title="긴급복지 지원 신고의무자 교육(교무팀)"><input type="checkbox" name="ubonline_progress[]" value="26" >긴급복지 지원 신고의무···</li>		</ul>	</li></ul><ul class="topmenu ubonline">	<li class="expand">		<a href="#">Knowledge<span class="caret"></span></a>		<ul class="ubonline_category">			<li><input type="checkbox" name="ubonline_cate_all" value="1" />Select all</li>		<li><input type="checkbox" name="ubonline_cate[]" value="1" >Social Science</li>		<li><input type="checkbox" name="ubonline_cate[]" value="2" >CTL</li>		<li><input type="checkbox" name="ubonline_cate[]" value="3" >geq</li>		<li><input type="checkbox" name="ubonline_cate[]" value="4" >SPL</li>		<li><input type="checkbox" name="ubonline_cate[]" value="5" >Biotechnology</li>		<li><input type="checkbox" name="ubonline_cate[]" value="6" >IPP</li>		<li><input type="checkbox" name="ubonline_cate[]" value="7" > Legal compulsory educ···</li>		<li><input type="checkbox" name="ubonline_cate[]" value="8" >Student Counseling Center</li>		<li><input type="checkbox" name="ubonline_cate[]" value="9" >General</li>		<li><input type="checkbox" name="ubonline_cate[]" value="10" >P.E</li>		<li><input type="checkbox" name="ubonline_cate[]" value="11" >Research Ethics Curric···</li>		<li><input type="checkbox" name="ubonline_cate[]" value="12" >ADM</li>		<li><input type="checkbox" name="ubonline_cate[]" value="13" >SW</li>		<li><input type="checkbox" name="ubonline_cate[]" value="14" >IRB</li>		<li><input type="checkbox" name="ubonline_cate[]" value="15" >JOB</li>		<li><input type="checkbox" name="ubonline_cate[]" value="16" >총무팀</li>		<li><input type="checkbox" name="ubonline_cate[]" value="17" >AAT</li>		</ul>	</li></ul><ul class="topmenu ubonline">	<li class="expand">		<a href="#">Language<span class="caret"></span></a>		<ul class="ubonline_category">			<li><input type="checkbox" name="ubonline_lang_all" value="1" />Select all</li>			<li><input type="checkbox" name="ubonline_lang[]" value="ko"  />Korean</li>			<li><input type="checkbox" name="ubonline_lang[]" value="en"  />English</li>		</ul>	</li></ul><div class="topmenu ubonline button"><input type="submit" class="btn btn-default" value="搜索"> </div>
			</form>
		</div>
	</div>
</li>

		</ul>
		        	</div>
	
</div>
				
				
				<div id="page-content" class="clearfix">
					<div id="page-content-wrap">
						<div class="page-content-navigation"><ol class=breadcrumb><li class="breadcrumb-home"><a href="https://lms.kyonggi.ac.kr"><img src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme_coursemosv2/1693408461/layout/course-home" alt="HOME" /></a></li><li><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="https://lms.kyonggi.ac.kr/local/ubonline/my.php"><span itemprop="title">Non-curriculum</span></a></span></li><li><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="https://lms.kyonggi.ac.kr/local/ubonline/intro.php"><span itemprop="title">How to create</span></a></span></li></ol></div>						<div id="region-main">
							<span class="notifications" id="user-notifications"></span><div role="main"><span id="maincontent"></span><h2>How to create</h2>

<div class="ubonline ubonline-mooc-intro">
	<div class="kg_mooc_box">
	  	<div class="kg_mooc_img kg_mooc_img01"></div>
	  
	  	<div class="kg_mooc_txt_box">
	    	<p class="kg_mooc_txt01">경기대학교는 자체적으로 구축한 플랫폼을 통해<br />
	     		재학생뿐 아니라 일반인에게 우수한 강좌를 서비스합니다.</p>
	    	<p class="kg_mooc_txt02">질의응답 토론 퀴즈 과제 제출 등을 통한 양방향 학습 및 <br />
	    		교수자 학습자 및 학습자 학습자간 상호작용 등<br />
	    		다양한 학습 활동을 제공하고 있습니다.</p>
	  	</div>
	  
	 	<div class="kg_mooc_img kg_mooc_img02"></div>
	</div>
</div>

</div>				            
			            </div>
		            </div>
				</div>
								<div class="coursemos-course-menu-expand">
					<button type="button" class="nobtn btn-course-menu btn-course-menu-open"></button>
					<button type="button" class="nobtn btn-course-menu btn-course-menu-close"></button>
				</div>
							</div>
		</div>
		
		<div id="page-footer">
			<ul class="footer-menus pull-left">
		<li><a href="http://www.kyonggi.ac.kr/webService.kgu?menuCode=K00M05020000" target="_blank">Privacy Policy</a></li>
</ul>
<!-- 
<div class="helpdesk">
	<a href="#" class="nobtn">도움말</a>
</div>
 -->
<div class="address">
	154-42, Kyounggi univ., Gwanggyosan-ro, Yeongtong-gu, Suwon-si, Gyeonggi-do, Republic of Korea T.+82-2-390-5114 <br/>
	<span class="copyright">
			</span>
</div>
<div id="back-top">
	<a href="#top"><span></span></a>
</div>
<div id="ajax_loading_submit">&nbsp;</div>
<div id="ajax_loading_container">
	<div id="ajax_loading_submit_img">
		<img src="https://lms.kyonggi.ac.kr/theme/image.php/coursemosv2/theme_coursemosv2/1693408461/ajax-loader" alt="loading..." /> Loading...
	</div>
	<div id="ajax_loading_message">
		<p class="save_msg">Data is saved. Please wait.</p>
		<p class="refresh_msg">Long period of time, if refresh(F5) while loading page please.</p>
	</div>
</div>	
		</div>
	</div>
	
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.5.1/js/iziModal.min.js"></script>

<script type="text/javascript" src="https://s3.ap-northeast-2.amazonaws.com/code.coursemos.co.kr/flexiblepage_cm32.js?v=0.10"></script>
<script type="text/javascript" src="https://s3.ap-northeast-2.amazonaws.com/code.coursemos.co.kr/annote_supporter.js?v=0.01"></script>



<script type="text/javascript" src="http://la.kyonggi.ac.kr/activeChecker/lms"></script><script type="text/javascript">
//<![CDATA[
var require = {
    baseUrl : 'https://lms.kyonggi.ac.kr/lib/requirejs.php/1693408461/',
    // We only support AMD modules with an explicit define() statement.
    enforceDefine: true,
    skipDataMain: true,
    waitSeconds : 0,

    paths: {
        jquery: 'https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/jquery/jquery-1.11.2.min',
        jqueryui: 'https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/jquery/ui-1.12.1/jquery-ui.min',
        jqueryprivate: 'https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/requirejs/jquery-private'
    },

    // Custom jquery config map.
    map: {
      // '*' means all modules will get 'jqueryprivate'
      // for their 'jquery' dependency.
      '*': { jquery: 'jqueryprivate' },

      // 'jquery-private' wants the real jQuery module
      // though. If this line was not here, there would
      // be an unresolvable cyclic dependency.
      jqueryprivate: { jquery: 'jquery' }
    }
};

//]]>
</script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/lib/javascript.php/1693408461/lib/requirejs/require.min.js"></script>
<script type="text/javascript">
//<![CDATA[
require(['core/first'], function() {
;
require(["media_videojs/loader"], function(loader) {
    loader.setUp(function(videojs) {
        videojs.options.flash.swf = "https://lms.kyonggi.ac.kr/media/player/videojs/videojs/video-js.swf";
videojs.addLanguage("zh-CN",{
 "Play": "播放",
 "Pause": "暂停",
 "Current Time": "当前时间",
 "Duration Time": "时长",
 "Remaining Time": "剩余时间",
 "Stream Type": "媒体流类型",
 "LIVE": "直播",
 "Loaded": "加载完毕",
 "Progress": "进度",
 "Fullscreen": "全屏",
 "Non-Fullscreen": "退出全屏",
 "Mute": "静音",
 "Unmute": "取消静音",
 "Playback Rate": "播放码率",
 "Subtitles": "字幕",
 "subtitles off": "字幕关闭",
 "Captions": "内嵌字幕",
 "captions off": "内嵌字幕关闭",
 "Chapters": "节目段落",
 "You aborted the media playback": "视频播放被终止",
 "A network error caused the media download to fail part-way.": "网络错误导致视频下载中途失败。",
 "The media could not be loaded, either because the server or network failed or because the format is not supported.": "视频因格式不支持或者服务器或网络的问题无法加载。",
 "The media playback was aborted due to a corruption problem or because the media used features your browser did not support.": "由于视频文件损坏或是该视频使用了你的浏览器不支持的功能，播放终止。",
 "No compatible source was found for this media.": "无法找到此视频兼容的源。",
 "The media is encrypted and we do not have the keys to decrypt it.": "视频已加密，无法解密。"
});

    });
});;

require(['core/yui'], function(Y) {
    M.util.init_skiplink(Y);
});
;
require(["core/notification"], function(amd) { amd.init(1, []); });;
require(["core/log"], function(amd) { amd.setConfig({"level":"warn"}); });
});
//]]>
</script>
<script type="text/javascript" src="https://lms.kyonggi.ac.kr/theme/javascript.php/coursemosv2/1693408461/footer"></script>
<script type="text/javascript">
//<![CDATA[
M.str = {"moodle":{"lastmodified":"\u6700\u540e\u4fee\u6539","name":"\u540d\u79f0","error":"\u9519\u8bef","info":"\u4fe1\u606f","yes":"\u662f\u7684","no":"\u5426","morehelp":"\u66f4\u591a\u5e2e\u52a9","loadinghelp":"\u8f7d\u5165\u4e2d\u2026\u2026","cancel":"\u53d6\u6d88","confirm":"\u786e\u8ba4","areyousure":"\u60a8\u786e\u5b9a\u5417\uff1f","closebuttontitle":"\u5173\u95ed","unknownerror":"\u672b\u77e5\u9519\u8bef"},"repository":{"type":"\u7c7b\u578b","size":"\u5927\u5c0f","invalidjson":"\u65e0\u6548\u7684JSON\u5b57\u7b26\u4e32","nofilesattached":"\u6ca1\u6709\u9644\u4ef6","filepicker":"\u6587\u4ef6\u9009\u62e9\u5668","logout":"\u767b\u51fa","nofilesavailable":"\u6ca1\u6709\u53ef\u7528\u6587\u4ef6","norepositoriesavailable":"\u62b1\u6b49\uff0c\u60a8\u4f7f\u7528\u7684\u5bb9\u5668\u90fd\u4e0d\u80fd\u8fd4\u56de\u7b26\u5408\u9700\u8981\u7684\u683c\u5f0f\u7684\u6587\u4ef6\u3002","fileexistsdialogheader":"\u6587\u4ef6\u5df2\u5b58\u5728","fileexistsdialog_editor":"\u60a8\u6b63\u7f16\u8f91\u7684\u6587\u672c\u7684\u9644\u4ef6\u4e2d\u5df2\u7ecf\u6709\u4e00\u4e2a\u540c\u540d\u6587\u4ef6\u3002","fileexistsdialog_filemanager":"\u5df2\u7ecf\u6709\u4e00\u4e2a\u540c\u540d\u6587\u4ef6","renameto":"\u91cd\u547d\u540d\u4e3a\u201c{$a}\u201d","referencesexist":"\u6709 {$a} \u4e2a\u522b\u540d\u6216\u5feb\u6377\u65b9\u5f0f\u5f15\u7528\u6b64\u6587\u4ef6","select":"\u9009\u62e9"},"admin":{"confirmdeletecomments":"\u60a8\u5c06\u5220\u9664\u8bc4\u8bba\uff0c\u786e\u5b9a\u5417\uff1f","confirmation":"\u786e\u8ba4"}};
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
(function() {setTimeout("fix_column_widths()", 20);
M.util.help_popups.setup(Y);
Y.use("moodle-core-popuphelp",function() {M.core.init_popuphelp();
});
 M.util.js_pending('random655313dc163fc2'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random655313dc163fc2'); });
})();
//]]>
</script>
</body>
</html>
