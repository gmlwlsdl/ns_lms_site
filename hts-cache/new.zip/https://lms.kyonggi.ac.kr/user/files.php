<!DOCTYPE html>
<html  lang="zh-cn" xml:lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>重定向</title>
</head><body><div style="margin-top: 3em; margin-left:auto; margin-right:auto; text-align:center;">本页会被自动重定向。如果什么都没发生，请点击下面的“继续”链接。<br /><a href="https://lms.kyonggi.ac.kr/login/index.php">继续</a></div></body></html>